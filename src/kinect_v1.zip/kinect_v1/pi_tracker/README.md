Skeleton Tracker Teleop Package for the Pi Robot Project.

The Hydro version (branch hydro-devel) has been catkinized and now depends on skeleton\_markers for the skeleton\_tracker node.
