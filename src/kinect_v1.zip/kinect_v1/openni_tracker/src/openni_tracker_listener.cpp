#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <geometry_msgs/Twist.h>
////////////////////////////////////////////////////#include "ros/ros.h"
#include <iostream>
#include "cv_bridge/cv_bridge.h"
#include "sensor_msgs/Image.h"
#include <opencv2/opencv.hpp>
#include <image_transport/image_transport.h>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Empty.h"
#include <stdio.h>
#include <vector>
#include <string>
#include <std_srvs/Empty.h>
#include <termios.h>  //dla getch()
#include "std_msgs/String.h"
#include <ros/package.h>
#include <dynamic_reconfigure/server.h>
#include <openni_tracker/set_kinect_v1Config.h>
#include <kinect_v1/dataHSV.h>

using namespace std;
using namespace cv;

ros::Publisher topictakeoff;
ros::Publisher topiclanding;
ros::Publisher cmd_vel;
ros::Publisher topicinfo;
ros::Publisher emergency;
ros::ServiceClient serviceflattrim;

float velocity=0.5;
float longitud, latitud, altitud;
int push_key_hand=0;
int push_key=0;
int marker1=0;
float maxX, minX, maxY, minY, maxZ, minZ, zerox, zeroy, zeroz, strefa;
static const string OPENCV_WINDOW = "Image window";

geometry_msgs::Twist changeTwist(float x, float y, float z, float turn)
{
    geometry_msgs::Twist msg_vel;
    msg_vel.angular.x = 0;
    msg_vel.angular.y = 0;
    msg_vel.angular.z = turn;
    msg_vel.linear.x = x;
    msg_vel.linear.y = y;
    msg_vel.linear.z = z;
    return(msg_vel);
}

void adjust (void)
{
    std_srvs::Empty srvflattrim;
    serviceflattrim.call(srvflattrim);
}
void emergency_function (void){


    std_msgs::Empty empty;

    emergency.publish(empty);

}

void takeoff (void)
{
    std_msgs::Empty empty;
    geometry_msgs::Twist msg_vel;
    topictakeoff.publish(empty);
    cout<<">>>Start<<<"<<endl;
    usleep(250000);
    msg_vel = changeTwist(0,0,0,0);
    cmd_vel.publish(msg_vel);
}

void land (void)
{
    std_msgs::Empty empty;
    topiclanding.publish(empty);
}

void forward (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(velocity,0,0,0);
    cmd_vel.publish(msg_vel);
}

void left (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,velocity,0,0);
    cmd_vel.publish(msg_vel);
}

void back (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-velocity,0,0,0);
    cmd_vel.publish(msg_vel);
}

void right (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,-velocity,0,0);
    cmd_vel.publish(msg_vel);
}

void up (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,0,velocity,0);
    cmd_vel.publish(msg_vel);
}

void down (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,0,-velocity,0);
    cmd_vel.publish(msg_vel);
}

void stop (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,0,0,0);
    cmd_vel.publish(msg_vel);
    //printf("stopping...\n");
}

//////////////////////////////////////////////////////////////////////////////////////////////
void up_left (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,velocity,velocity,0);
    cmd_vel.publish(msg_vel);
}

void up_right (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,-velocity,velocity,0);
    cmd_vel.publish(msg_vel);
}


void down_right (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,-velocity,-velocity,0);
    cmd_vel.publish(msg_vel);
}

void down_left (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0,velocity,-velocity,0);
    cmd_vel.publish(msg_vel);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

void back_left (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-velocity,velocity,0,0);
    cmd_vel.publish(msg_vel);
}


void back_right (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-velocity,-velocity,0,0);
    cmd_vel.publish(msg_vel);
}


void forward_right (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(velocity,-velocity,0,0);
    cmd_vel.publish(msg_vel);
}


void forward_left (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(velocity,velocity,0,0);
    cmd_vel.publish(msg_vel);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////


void up_back (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-velocity,0,velocity,0);
    cmd_vel.publish(msg_vel);
}


void up_forward (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(velocity,0,velocity,0);
    cmd_vel.publish(msg_vel);
}


void down_back (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-velocity,0,-velocity,0);
    cmd_vel.publish(msg_vel);
}


void down_forward (void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(velocity,0,-velocity,0);
    cmd_vel.publish(msg_vel);
}

void turn (void)
{
    geometry_msgs::Twist msg_vel; //info velocity
    msg_vel = changeTwist(0,0,0,1);
    cmd_vel.publish(msg_vel);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
int getch()
{
    static struct termios oldt, newt;
    tcgetattr( STDIN_FILENO, &oldt);           // save old settings
    newt = oldt;
    newt.c_lflag &= ~(ICANON);                 // disable buffering
    tcsetattr( STDIN_FILENO, TCSANOW, &newt);  // apply new settings

    int c = getchar();  // read character (non-blocking)

    tcsetattr( STDIN_FILENO, TCSANOW, &oldt);  // restore old settings
    return c;
}
//////////////////////////////OKNO OPENCV KINECT///////////////////////////////////
class ImageConverter_kinect
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Subscriber image_sub_depth;
  image_transport::Subscriber image_sub_threshold;
  image_transport::Publisher image_pub_;
  image_transport::Publisher image_pub_depth;
  image_transport::Publisher image_pub_threshold;
public:
  ImageConverter_kinect()
  : it_(nh_)
{
  image_sub_ = it_.subscribe("/camera/rgb/image_color",1,
   &ImageConverter_kinect::imageCb, this);
  cv::namedWindow(OPENCV_WINDOW);
  image_pub_ = it_.advertise("/image_converter/output_video",1);
}

~ImageConverter_kinect()
{
  cv::destroyWindow(OPENCV_WINDOW);
}

void imageCb(const sensor_msgs::ImageConstPtr& msg)
{
  cv_bridge::CvImagePtr cv_ptr;
  try
  {
  cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
  }
  catch (cv_bridge::Exception& e)
  {
   ROS_ERROR("cv_bridge exception: %s", e.what());
  }


  cv::imshow(OPENCV_WINDOW, cv_ptr->image);
  }
};


void reconfigure(openni_tracker::set_kinect_v1 &config)
{
    data.h1 = config.H1;
    data.s1 = config.S1;
    data.v1 = config.V1;
    data.h2 = config.H2;
    data.s2 = config.S2;
    data.v2 = config.V2;
}





/////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char** argv)
{

  dynamic_reconfigure::Server<openni_tracker::set_HSVConfig> server;
  dynamic_reconfigure::Server<openni_tracker::set_HSVConfig>::CallbackType f;
  f = boost::bind(&ImageConverter::reconfigure, boost::ref(ic), _1);
  server.setCallback(f);








    ros::init(argc, argv, "openni_tracker_listener");

    ros::NodeHandle node;

    // publisher declaration
    ros::Publisher neck_joint = node.advertise<geometry_msgs::Point>("neck_joint", 1);
    ros::Publisher head_joint = node.advertise<geometry_msgs::Point>("head_joint", 1);
    ros::Publisher torso_joint = node.advertise<geometry_msgs::Point>("torso_joint", 1);
    ros::Publisher left_shoulder_joint = node.advertise<geometry_msgs::Point>("left_shoulder_joint", 1);
    ros::Publisher left_elbow_joint = node.advertise<geometry_msgs::Point>("left_elbow_joint", 1);
    ros::Publisher left_hand_joint = node.advertise<geometry_msgs::Point>("left_hand_joint", 1);
    ros::Publisher right_shoulder_joint = node.advertise<geometry_msgs::Point>("right_shoulder_joint", 1);
    ros::Publisher right_elbow_joint = node.advertise<geometry_msgs::Point>("right_elbow_joint", 1);
    ros::Publisher right_hand_joint = node.advertise<geometry_msgs::Point>("right_hand_joint", 1);
    ros::Publisher left_hip_joint = node.advertise<geometry_msgs::Point>("left_hip_joint", 1);
    ros::Publisher left_knee_joint = node.advertise<geometry_msgs::Point>("left_knee_joint", 1);
    ros::Publisher left_foot_joint = node.advertise<geometry_msgs::Point>("left_foot_joint", 1);
    ros::Publisher right_hip_joint = node.advertise<geometry_msgs::Point>("right_hip_joint", 1);
    ros::Publisher right_knee_joint = node.advertise<geometry_msgs::Point>("right_knee_joint", 1);
    ros::Publisher right_foot_joint = node.advertise<geometry_msgs::Point>("right_foot_joint", 1);


    tf::TransformListener listener;

    ros::Rate rate(30.0);

    /////////////////////////////WYBOR STEROWANIA//////////////////////////////////////
   cout<<"Dron zaincjalizowany. W celu wyboru interfejsu sterowania wcisnij"<<endl;
    cout<<"2 - sterowanie dlonia"<<endl;

    push_key=getch();



    if(push_key=='2')//dlon
    {


        cout<<"Wybrano sterowanie dlonia."<<endl<<""<<endl<<endl;
        //DRONE PART
        ros::init(argc, argv, "drone");
        ros::NodeHandle n;
        topictakeoff = n.advertise<std_msgs::Empty>("/ardrone/takeoff",1,true);
        topiclanding = n.advertise<std_msgs::Empty>("/ardrone/land",1,true);
        emergency= n.advertise<std_msgs::Empty>("/ardrone/reset",1,true);
        cmd_vel = n.advertise<geometry_msgs::Twist>("/cmd_vel",1,true);
        serviceflattrim = n.serviceClient<std_srvs::Empty>("/ardrone/flattrim");

        ////////////////////////////////////////CZESC ODPOWIEDZIALNA ZA STEROWANIE DLONIA//////////////////////////////////////////////////////


        ros::init(argc,argv, "image_converter");
        ImageConverter_kinect ic;
        while (node.ok())
        {
            // Transforms declared for each joint
            tf::StampedTransform transform_neck, transform_head, transform_torso,
                    transform_left_shoulder, transform_left_elbow, transform_left_hand,
                    transform_right_shoulder, transform_right_elbow, transform_right_hand,
                    transform_left_hip, transform_left_knee, transform_left_foot,
                    transform_right_hip, transform_right_knee, transform_right_foot;
            try
            {

              //  listener.waitForTransform("/neck_1", "/openni_depth_frame", ros::Time(0), ros::Duration(10.0) );

                listener.lookupTransform("/neck_1", "/openni_depth_frame",ros::Time(0), transform_neck);
                listener.lookupTransform("/head_1", "/openni_depth_frame",ros::Time(0), transform_head);
                listener.lookupTransform("/torso_1", "/openni_depth_frame",ros::Time(0), transform_torso);
                listener.lookupTransform("/left_shoulder_1", "/openni_depth_frame",ros::Time(0), transform_left_shoulder);
                listener.lookupTransform("/left_elbow_1", "/openni_depth_frame",ros::Time(0), transform_left_elbow);
                listener.lookupTransform("/left_hand_1", "/openni_depth_frame",ros::Time(0), transform_left_hand);
                listener.lookupTransform("/right_shoulder_1", "/openni_depth_frame",ros::Time(0), transform_right_shoulder);
                listener.lookupTransform("/right_elbow_1", "/openni_depth_frame",ros::Time(0), transform_right_elbow);
                listener.lookupTransform("/right_hand_1", "/openni_depth_frame",ros::Time(0), transform_right_hand);
                //listener.lookupTransform("/left_hip_1", "/openni_depth_frame",ros::Time(0), transform_left_hip);
                //listener.lookupTransform("/left_knee_1", "/openni_depth_frame",ros::Time(0), transform_left_knee);
                //listener.lookupTransform("/left_foot_1", "/openni_depth_frame",ros::Time(0), transform_left_foot);
                //listener.lookupTransform("/right_hip_1", "/openni_depth_frame",ros::Time(0), transform_right_hip);
                //listener.lookupTransform("/right_knee_1", "/openni_depth_frame",ros::Time(0), transform_right_knee);
                //listener.lookupTransform("/right_foot_1", "/openni_depth_frame",ros::Time(0), transform_right_foot);

            }

            catch (tf::TransformException &ex)
            {
                ROS_ERROR("%s",ex.what());
                ros::Duration(0.10).sleep();
                continue;
            }

            geometry_msgs::Point neck_pose, head_pose, torso_pose,
                    left_shoulder_pose, left_elbow_pose, left_hand_pose,
                    right_shoulder_pose, right_elbow_pose, right_hand_pose,
                    left_hip_pose, left_knee_pose, left_foot_pose,
                    right_hip_pose, right_knee_pose, right_foot_pose;

            // neck joint
            neck_pose.x = transform_neck.getOrigin().x();
            neck_pose.y = transform_neck.getOrigin().y();
            neck_pose.z = transform_neck.getOrigin().z();
            // head joint
            head_pose.x = transform_head.getOrigin().x();
            head_pose.y = transform_head.getOrigin().y();
            head_pose.z = transform_head.getOrigin().z();
            // torso joint
            torso_pose.x = transform_torso.getOrigin().x();
            torso_pose.y = transform_torso.getOrigin().y();
            torso_pose.z = transform_torso.getOrigin().z();
            // left shoulder joint
            left_shoulder_pose.x = transform_left_shoulder.getOrigin().x();
            left_shoulder_pose.y = transform_left_shoulder.getOrigin().y();
            left_shoulder_pose.z = transform_left_shoulder.getOrigin().z();
            // left elbow joint
            left_elbow_pose.x = transform_left_elbow.getOrigin().x();
            left_elbow_pose.y = transform_left_elbow.getOrigin().y();
            left_elbow_pose.z = transform_left_elbow.getOrigin().z();
            // left hand joint
            left_hand_pose.x = transform_left_hand.getOrigin().x();
            left_hand_pose.y = transform_left_hand.getOrigin().y();
            left_hand_pose.z = transform_left_hand.getOrigin().z();
            // right shoulder joint
            right_shoulder_pose.x = transform_right_shoulder.getOrigin().x();
            right_shoulder_pose.y = transform_right_shoulder.getOrigin().y();
            right_shoulder_pose.z = transform_right_shoulder.getOrigin().z();
            // right elbow joint
            right_elbow_pose.x = transform_right_elbow.getOrigin().x();
            right_elbow_pose.y = transform_right_elbow.getOrigin().y();
            right_elbow_pose.z = transform_right_elbow.getOrigin().z();
            // right hand joint
            right_hand_pose.x = transform_right_hand.getOrigin().x();
            right_hand_pose.y = transform_right_hand.getOrigin().y();
            right_hand_pose.z = transform_right_hand.getOrigin().z();
            // left hip joint
            left_hip_pose.x = transform_left_hip.getOrigin().x();
            left_hip_pose.y = transform_left_hip.getOrigin().y();
            left_hip_pose.z = transform_left_hip.getOrigin().z();
            // left knee joint
            left_knee_pose.x = transform_left_knee.getOrigin().x();
            left_knee_pose.y = transform_left_knee.getOrigin().y();
            left_knee_pose.z = transform_left_knee.getOrigin().z();
            // left foot joint
            left_foot_pose.x = transform_left_foot.getOrigin().x();
            left_foot_pose.y = transform_left_foot.getOrigin().y();
            left_foot_pose.z = transform_left_foot.getOrigin().z();
            // right hip joint
            right_hip_pose.x = transform_right_hip.getOrigin().x();
            right_hip_pose.y = transform_right_hip.getOrigin().y();
            right_hip_pose.z = transform_right_hip.getOrigin().z();
            // right knee joint
            right_knee_pose.x = transform_right_knee.getOrigin().x();
            right_knee_pose.y = transform_right_knee.getOrigin().y();
            right_knee_pose.z = transform_right_knee.getOrigin().z();
            // right foot joint
            right_foot_pose.x = transform_right_foot.getOrigin().x();
            right_foot_pose.y = transform_right_foot.getOrigin().y();
            right_foot_pose.z = transform_right_foot.getOrigin().z();

            // joint positions publish
            neck_joint.publish(neck_pose);
            head_joint.publish(head_pose);
            torso_joint.publish(torso_pose);
            left_shoulder_joint.publish(left_shoulder_pose);
            left_elbow_joint.publish(left_elbow_pose);
            left_hand_joint.publish(left_hand_pose);
            right_shoulder_joint.publish(right_shoulder_pose);
            right_elbow_joint.publish(right_elbow_pose);
            right_hand_joint.publish(right_hand_pose);
            left_hip_joint.publish(left_hip_pose);
            left_knee_joint.publish(left_knee_pose);
            left_foot_joint.publish(left_foot_pose);
            right_hip_joint.publish(right_hip_pose);
            right_knee_joint.publish(right_knee_pose);
            right_foot_joint.publish(right_foot_pose);


            if(push_key_hand==50 && marker1==1) //prawa dlon
            {
                if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    stop();
                    cout<<"stop"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>maxY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    up();
                    cout<<"gora"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y<minY && right_hand_pose.z>minZ && right_hand_pose.z<maxZ)
                {
                    down();
                    cout<<"dol"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    right();
                    cout<<"prawo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x<minX && right_hand_pose.y>minY && right_hand_pose.y<maxY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    left();
                    cout<<"lewo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY && right_hand_pose.z<minZ)
                {
                    back();
                    cout<<"tyl"<<"     X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY && right_hand_pose.z>maxZ)
                {
                    forward();
                    cout<<"przod"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(right_hand_pose.x>maxX && right_hand_pose.y>maxY && right_hand_pose.z>minZ && right_hand_pose.z<maxZ)
                {
                    up_right();
                    cout<<"gora_prawo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x<minX && right_hand_pose.y>maxY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    up_left();
                    cout<<"gora_lewo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                else if(right_hand_pose.x>maxX && right_hand_pose.y<minY && right_hand_pose.z>minZ  && right_hand_pose.z<maxZ)
                {
                    down_right();
                    cout<<"dol_prawo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x<minX && right_hand_pose.y<minY && right_hand_pose.z>minZ && right_hand_pose.z<maxZ)
                {
                    down_left();
                    cout<<"dol_lewo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(right_hand_pose.x>maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY  && right_hand_pose.z>maxZ)
                {
                    forward_right();
                    cout<<"przod_prawo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x<minX && right_hand_pose.y>minY && right_hand_pose.y<maxY  && right_hand_pose.z>maxZ)
                {
                    forward_left();
                    cout<<"przod_lewo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>maxX && right_hand_pose.y>minY && right_hand_pose.y<maxY  && right_hand_pose.z<minZ)
                {
                    back_right();
                    cout<<"tyl_prawo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                else if(right_hand_pose.x<minX && right_hand_pose.y>minY && right_hand_pose.y<maxY  && right_hand_pose.z<minZ)
                {
                    back_left();
                    cout<<"tyl_lewo"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>maxY && right_hand_pose.z>maxZ)
                {
                    up_forward();
                    cout<<"gora_przod"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y>maxY && right_hand_pose.z<minZ)
                {
                    up_back();
                    cout<<"gora_tyl"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y<minY && right_hand_pose.z>maxZ)
                {
                    down_forward();
                    cout<<"dol_przod"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;
                }
                else if(right_hand_pose.x>minX && right_hand_pose.x<maxX && right_hand_pose.y<minY && right_hand_pose.z<minZ)
                {
                    down_back();
                    cout<<"dol_tyl"<<"    X: "<<right_hand_pose.x<<"    Y: "<<right_hand_pose.y<<"    Z : "<<right_hand_pose.z<<endl;

                }
}
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            else if (push_key_hand==49 && marker1==0) //wczytanie aktualnej pozycji LEWEJ DLONI
            {

                zerox=left_hand_pose.x;
                zeroy=left_hand_pose.y;
                zeroz=left_hand_pose.z;
                strefa=0.2;

                maxX=zerox+strefa;
                minX=zerox-strefa;

                maxY=zeroy+strefa;
                minY=zeroy-strefa;

                maxZ=zeroz+strefa;
                minZ=zeroz-strefa;



                cout<<endl<<endl<<"Sterowanie lewa dlonia rozpoczete!"<<endl<<endl;
                marker1=1;


            }




            else if (push_key_hand==50 && marker1==0) //wczytanie aktualnej pozycji PRAWEJ DLONI
            {

                zerox=right_hand_pose.x;
                zeroy=right_hand_pose.y;
                zeroz=right_hand_pose.z;
                strefa=0.2;

                maxX=zerox+strefa;
                minX=zerox-strefa;

                maxY=zeroy+strefa;
                minY=zeroy-strefa;

                maxZ=zeroz+strefa;
                minZ=zeroz-strefa;


                cout<<endl<<endl<<"Sterowanie prawa dlonia rozpoczete!"<<endl<<endl;
                marker1=1;
            }


            else if(push_key_hand==49 && marker1==1) // lewa dlon
            {
                if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    stop();
                    cout<<"stop"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>maxY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    up();
                    cout<<"gora"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y<minY && left_hand_pose.z>minZ && left_hand_pose.z<maxZ)
                {
                    down();
                    cout<<"dol"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    right();
                    cout<<"prawo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x<minX && left_hand_pose.y>minY && left_hand_pose.y<maxY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    left();
                    cout<<"lewo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY && left_hand_pose.z<minZ)
                {
                    back();
                    cout<<"tyl"<<"     X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY && left_hand_pose.z>maxZ)
                {
                    forward();
                    cout<<"przod"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(left_hand_pose.x>maxX && left_hand_pose.y>maxY && left_hand_pose.z>minZ && left_hand_pose.z<maxZ)
                {
                    up_right();
                    cout<<"gora_prawo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x<minX && left_hand_pose.y>maxY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    up_left();
                    cout<<"gora_lewo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                else if(left_hand_pose.x>maxX && left_hand_pose.y<minY && left_hand_pose.z>minZ  && left_hand_pose.z<maxZ)
                {
                    down_right();
                    cout<<"dol_prawo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x<minX && left_hand_pose.y<minY && left_hand_pose.z>minZ && left_hand_pose.z<maxZ)
                {
                    down_left();
                    cout<<"dol_lewo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(left_hand_pose.x>maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY  && left_hand_pose.z>maxZ)
                {
                    forward_right();
                    cout<<"przod_prawo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x<minX && left_hand_pose.y>minY && left_hand_pose.y<maxY  && left_hand_pose.z>maxZ)
                {
                    forward_left();
                    cout<<"przod_lewo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>maxX && left_hand_pose.y>minY && left_hand_pose.y<maxY  && left_hand_pose.z<minZ)
                {
                    back_right();
                    cout<<"tyl_prawo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                else if(left_hand_pose.x<minX && left_hand_pose.y>minY && left_hand_pose.y<maxY  && left_hand_pose.z<minZ)
                {
                    back_left();
                    cout<<"tyl_lewo"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>maxY && left_hand_pose.z>maxZ)
                {
                    up_forward();
                    cout<<"gora_przod"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y>maxY && left_hand_pose.z<minZ)
                {
                    up_back();
                    cout<<"gora_tyl"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y<minY && left_hand_pose.z>maxZ)
                {
                    down_forward();
                    cout<<"dol_przod"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;
                }
                else if(left_hand_pose.x>minX && left_hand_pose.x<maxX && left_hand_pose.y<minY && left_hand_pose.z<minZ)
                {
                    down_back();
                    cout<<"dol_tyl"<<"    X: "<<left_hand_pose.x<<"    Y: "<<left_hand_pose.y<<"    Z : "<<left_hand_pose.z<<endl;

                }
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                //  cout<<"zerox:"<<zerox<<"     zeroy:"<<zeroy<<"     zeroz:"<<zeroz<<endl;

            }
            else
            {

                cout<<endl<<"Wybierz, ktora dlonia chcesz sterowac dronem."<<endl<<"UWAGA! Po dokonaniu wyboru masz trzy sekundy na ustawienie reki w dogodnej pozycji."<<endl<<"1 - lewa dlon"<<endl<<"2 - prawa dlon"<<endl<<endl;
               // marker1=0;
                push_key_hand=getch();


                cout<<">>>>>3<<<<<"<<endl;
                sleep(1);
                cout<<">>>>>2<<<<<"<<endl;
                sleep(1);
                cout<<">>>>>1<<<<<"<<endl;
                sleep(1);
            }
            rate.sleep();


            ///////////////////////////////////////KONIEC CZESCI ODPOWIEDZIALNEJ ZA STEROWANIE DLONIA/////////////////////////////////////////////

            //cout<<left_hand_pose.x<<endl<<left_hand_pose.y<<endl<<left_hand_pose.z<<endl<<endl;
            //cout<<right_hand_pose.x<<"<<endl<<right_hand_pose.y<<endl<<right_hand_pose.z<<endl<<endl;

        }

}




    return 0;
}
