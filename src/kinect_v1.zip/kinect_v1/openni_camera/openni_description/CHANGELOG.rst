^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package openni_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.1 (2018-09-13)
-------------------
* Remove a test_depend on pkg that are not guaranteed to be available in newer distro. `#70 <https://github.com/ros-drivers/openni_camera/issues/70>`_
* Contributors: Isaac I.Y. Saito

1.11.0 (2018-01-13)
-------------------
* Initial release. See https://discourse.ros.org/t/common-location-for-sensor-urdf-files/1758/
* Contributors: Isaac I.Y. Saito

1.10.0 (2018-01-06)
-------------------

1.9.5 (2016-03-31)
------------------

1.9.4 (2015-10-27)
------------------

1.9.3 (2015-10-17)
------------------

1.9.2 (2014-01-17 14:11)
------------------------

1.9.1 (2014-01-17 13:29)
------------------------

1.9.0 (2013-06-27)
------------------

1.8.8 (2013-01-08)
------------------

1.8.7 (2013-01-04)
------------------

1.8.6 (2013-01-03)
------------------
